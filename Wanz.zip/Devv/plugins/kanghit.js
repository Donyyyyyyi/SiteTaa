let axios = require('axios')

function apivisit() {
axios.get(`https://status.pnggilajacn.my.id`);
axios.get(`https://status.pnggilajacn.my.id`);
}
module.exports = { apivisit }